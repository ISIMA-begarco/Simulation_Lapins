var searchData=
[
  ['write',['write',['../class_lapin_manager.html#a39c86592d84820c11b058863f2002d50',1,'LapinManager']]]
];
