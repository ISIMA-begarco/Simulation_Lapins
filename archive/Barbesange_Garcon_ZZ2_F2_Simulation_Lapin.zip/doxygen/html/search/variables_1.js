var searchData=
[
  ['infty_5f',['infty_',['../class_student.html#acc64dd466b07ae132c1f25525aa1f3f2',1,'Student']]]
];
