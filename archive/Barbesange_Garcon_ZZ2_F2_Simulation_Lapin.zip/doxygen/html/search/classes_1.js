var searchData=
[
  ['lapinmanager',['LapinManager',['../class_lapin_manager.html',1,'']]]
];
