var searchData=
[
  ['getquantile',['getQuantile',['../class_student.html#a4779459057680ace4caeb47ef88a9f7d',1,'Student']]]
];
