var searchData=
[
  ['simulation',['simulation',['../class_lapin_manager.html#abd88d03f96c22f14140a9027a88809ec',1,'LapinManager']]],
  ['student',['Student',['../class_student.html#af9168cedbfa5565cf0b20c1a9d3f5c9d',1,'Student']]]
];
