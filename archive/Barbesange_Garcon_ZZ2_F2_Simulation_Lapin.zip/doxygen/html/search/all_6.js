var searchData=
[
  ['off_5f120_5f80',['off_120_80',['../class_student.html#a9ff92b6fef8b635ec5686751ff101636',1,'Student']]],
  ['off_5f40_5f30',['off_40_30',['../class_student.html#ab008a58e27b36e3069b502e953c5a0f9',1,'Student']]],
  ['off_5f80_5f40',['off_80_40',['../class_student.html#a201153fbbe0f40e14d8060134ca0de6c',1,'Student']]]
];
