var _lapin_manager_8h =
[
    [ "LapinManager", "class_lapin_manager.html", "class_lapin_manager" ],
    [ "INTEGER", "_lapin_manager_8h.html#a0391012cd99f054647804c6a44d6f53b", null ]
];