var class_student =
[
    [ "Student", "class_student.html#af9168cedbfa5565cf0b20c1a9d3f5c9d", null ],
    [ "~Student", "class_student.html#a54a8ea060d6cd04222c3a2f89829f105", null ],
    [ "getQuantile", "class_student.html#a4779459057680ace4caeb47ef88a9f7d", null ],
    [ "coeff_120_80_", "class_student.html#a40e9b5176961738a27754dceb0052a5d", null ],
    [ "coeff_40_30_", "class_student.html#aae51cf7d68f939ced3fcdda40368b823", null ],
    [ "coeff_80_40_", "class_student.html#a2ab99b10f14c201749a714a4e94be22d", null ],
    [ "infty_", "class_student.html#acc64dd466b07ae132c1f25525aa1f3f2", null ],
    [ "off_120_80", "class_student.html#a9ff92b6fef8b635ec5686751ff101636", null ],
    [ "off_40_30", "class_student.html#ab008a58e27b36e3069b502e953c5a0f9", null ],
    [ "off_80_40", "class_student.html#a201153fbbe0f40e14d8060134ca0de6c", null ],
    [ "values_", "class_student.html#a6252dc779c07decf5e2e5cffd0dae87d", null ]
];