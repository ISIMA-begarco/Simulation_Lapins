var annotated_dup =
[
    [ "ClasseLapins", "class_classe_lapins.html", "class_classe_lapins" ],
    [ "LapinManager", "class_lapin_manager.html", "class_lapin_manager" ],
    [ "Student", "class_student.html", "class_student" ]
];