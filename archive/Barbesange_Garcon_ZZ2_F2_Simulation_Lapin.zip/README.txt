-----------------------------------------------------------
---------- SIMULATION D'UNE POPULATION DE LAPINS ----------
-----------------------------------------------------------
----------- GARCON BENOIT & BARBESANGE BENJAMIN -----------
-----------------------------------------------------------

Vous trouverez la documentation g�n�r�e par doxygen en
ouvrant le raccourcis Documentation de ce r�pertoire.

Vous pouvez utiliser le Makefile pour recompiler le
programme sur votre machine pour ex�cuter les tests
vous m�me.
Vous devez disposer d'une version de g++ prennant en
charge les options de compilation pour le C++11.

Vous trouverez une version pdf du rapport dans ce 
r�pertoire �galement.


-----------------------------------------------------------
---------------------------------------------- ISIMA 2015 -